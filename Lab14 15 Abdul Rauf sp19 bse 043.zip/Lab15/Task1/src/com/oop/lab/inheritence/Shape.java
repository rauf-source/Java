/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.oop.lab.inheritence;

/**
 *
 * @author admin
 */
public class Shape {
    private String color;

    public Shape(String color) {
        this.color = color;
    }
    
    
    
    public double calculateArea(){
        return 0;
    }
    public double calculatePerimeter(){
        return 0;
    }
    
}
